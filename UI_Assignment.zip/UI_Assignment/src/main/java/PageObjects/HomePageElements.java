package PageObjects;

public interface HomePageElements {

	String revenueCalculatorElement="//div[contains(text(),'Revenue Calculator')]";
}
