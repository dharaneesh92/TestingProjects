package Utils;

public interface Constants {
  String url="https://www.fitpeo.com/";
}
